# Design System Strategy: The Synthetic Singularity

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Synthetic Singularity."** This aesthetic sits at the volatile intersection of biological evolution and quantum computing. It is not a static interface; it is a living, breathing laboratory environment.

To move beyond the "template" look of modern SaaS, this system rejects the rigid, boxy constraints of standard grids. Instead, we utilize **intentional asymmetry**, **depth through luminosity**, and **holographic layering**. Elements should appear as if they are projected in a high-density void or cultivated in a digital petri dish. We favor high-contrast typography scales—where massive, geometric headings collide with microscopic, precise data points—to create an editorial feel that commands authority and signals cutting-edge innovation.

---

## 2. Color & Atmospheric Depth
Our palette is rooted in the "Dark Matter" spectrum, moving from the absolute zero of `--void` to the hyper-lucid glow of our accent tokens.

### Surface Hierarchy & Nesting
Depth is achieved through a "Biological Stacking" logic. Instead of using shadows to lift elements, we use the natural luminescence of the laboratory:
*   **Base Layer:** `--void` (#03040a) for the canvas.
*   **Sectional Shifts:** Use `--abyss` (#06080f) for large structural blocks.
*   **Active Containers:** Use `--deep` (#0a0e1a) for cards and primary interaction zones.
*   **Floating Elements:** Use `--surface` (#0f1628) or `--glass` for transient UI like modals or tooltips.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to define section boundaries. Structural separation must be achieved through:
1.  **Tonal Shifts:** Placing a `surface-container-low` element against a `surface-container-lowest` background.
2.  **Negative Space:** Utilizing the `Spacing Scale` (specifically steps `8` through `16`) to create "void-gaps" between content blocks.
3.  **Luminescent Fills:** Using a subtle `primary` glow to define the edge of a container rather than a stroke.

### Signature Textures
To escape the "flat" digital feel, all surfaces must incorporate a **Subtle Grain Texture** (2-3% opacity overlay). Apply a linear gradient (e.g., `primary` to `secondary` at 15% opacity) to hero backgrounds to simulate "Quantum Bleed."

---

## 3. Typography: The Editorial Scale
The typography strategy creates a tension between the "Brutal" and the "Scientific."

*   **The Power Layer (Display/Headline):** We use **Syne** in ultra-bold weights. This geometric, futuristic typeface is our "Biopunk" voice. Use `display-lg` (3.5rem) and `headline-lg` (2rem) for high-impact editorial moments. Letter spacing should be tightened (-0.02em) to feel compressed and high-energy.
*   **The Utility Layer (Body):** We use the **system-ui** stack for maximum legibility. This represents the "Standardized Lab Equipment"—reliable and invisible. 
*   **The Data Layer (Numbers/Code):** **JetBrains Mono** is mandatory for all numerical data, timestamps, and quantum coordinates. This reinforces the "Quantum Laboratory" narrative, suggesting that every number is a piece of raw, unedited telemetry.

---

## 4. Elevation & Depth: Tonal Layering
Traditional structural lines are a legacy constraint. In this design system, we define space through light and density.

### The Layering Principle
Stacking follows a strict hierarchy. A card (`surface-container-highest`) sitting on a section (`surface-container-low`) creates a natural, soft lift. This "Tonal Layering" mimics physical objects in a low-light environment.

### Ambient Shadows & Neon Glows
Standard "Drop Shadows" are forbidden. Instead:
*   **Floating State:** Use an **Extra-Diffused Glow**. If an element is "floating," it should cast a light, not a shadow. Use the `primary` (indigo) or `secondary` (violet) token at 8% opacity with a 40px–60px blur.
*   **Ghost Borders:** If a boundary is strictly required for accessibility, use `outline-variant` (#464751) at **10% opacity**. It should be felt, not seen.

### Glassmorphism
Apply `backdrop-filter: blur(12px)` to any element using the `--glass` token. This allows the biological textures and "dark matter" backgrounds to bleed through, ensuring the UI feels integrated into the environment.

---

## 5. Components: The Lab Kit

### Interaction Nodes (Buttons)
*   **Primary:** A gradient-filled container (`primary` to `secondary`). No border. High-contrast text (`on-primary`). Use `0.25rem` (DEFAULT) rounding for a precise, "machined" look.
*   **Tertiary:** Text-only in `indigo`, but on hover, trigger a "holographic" underline using the `cyan` accent.

### Quantum Input Fields
*   **Style:** Background set to `--abyss`. Use a "Ghost Border" that illuminates to `emerald` (accent 2) when active, simulating a successful data connection.
*   **Font:** Must use `JetBrains Mono` for the input text to maintain the lab aesthetic.

### Bio-Data Cards
*   **Structure:** No dividers. Use `Spacing Scale: 4` (1.4rem) to separate internal elements.
*   **Visuals:** Incorporate a subtle "holographic overlay" (a faint, 5% opacity diagonal line pattern) in the card header to distinguish it from standard containers.

### Status Indicators (The Bio-Scale)
Use the accent palette strictly for state:
*   `Emerald`: Stable/Biological Success.
*   `Amber`: Quantum Fluctuation/Warning.
*   `Rose`: Critical Containment Failure.
*   **Style:** Do not use flat circles. Use small, glowing "pills" with a `blur(2px)` effect to simulate bioluminescence.

---

## 6. Do’s and Don’ts

### Do
*   **DO** use intentional asymmetry. Offset your grid columns to create a "custom-built" editorial feel.
*   **DO** use `JetBrains Mono` for every single digit. Numbers are data; treat them as such.
*   **DO** lean into the "Void." Large areas of `#03040a` are not "empty space"—they are the canvas of the experiment.
*   **DO** overlap elements. Allow a glass modal to partially obscure a heading to create 3D depth.

### Don’t
*   **DON'T** use 1px solid borders. It shatters the "holographic" immersion.
*   **DON'T** use standard grey shadows. Shadows should be tinted with the `indigo` or `violet` primary tones.
*   **DON'T** use generic iconography. Icons must be thin-stroke (1.5px) and match the `JetBrains Mono` aesthetic.
*   **DON'T** over-round corners. Stick to `DEFAULT` (4px) or `sm` (2px). Anything more feels too "friendly" and consumer-grade for a Quantum Lab.